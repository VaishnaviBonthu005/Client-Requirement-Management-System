<?php
if (!isset($_COOKIE["uname"])) {
    header("Location: login.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shiva";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$project_details = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $project_name = $_POST['project_name'];

    $sql = "SELECT * FROM project_info WHERE project_name = '$project_name'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $project_details = "
            <h3>Project Details</h3>
            <table>
                <tr><td><strong>Project Name</strong></td><td class='wide-field'>{$row['project_name']}</td></tr>
                <tr><td><strong>Deadline</strong></td><td>{$row['deadline']}</td></tr>
                <tr><td><strong>Type</strong></td><td>{$row['type']}</td></tr>
                <tr><td><strong>Description</strong></td><td>{$row['description']}</td></tr>
                <tr><td><strong>Status</strong></td><td>{$row['status']}</td></tr>
            </table>";
    } else {
        $project_details = "<p style='color: red;'>No project found with that name.</p>";
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retrieve Project - V-Coder Technologies</title>
    <style>
        body {
            background: url('https://img.freepik.com/free-photo/abstract-networking-concept-still-life-assortment_23-2149035715.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Lucida Calligraphy', cursive;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            flex-direction: column;
        }
        a
        {
            color:white;
        }
        form {
            background: rgba(0, 0, 0, 0.6);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        table {
            width: 80%;
            border-collapse: collapse;
            margin-top: 20px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            overflow: hidden;
        }
        td {
            padding: 12px;
            border: 1px solid white;
        }
        .wide-field {
            width: 300px; /* Make Project Name field wider */
            word-wrap: break-word;
        }
        input {
            width: 100%;
            padding: 8px;
            border-radius: 5px;
            border: none;
            font-family: 'Lucida Calligraphy', cursive;
        }
        .btn {
            background: #5c67f2;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }
        .btn:hover {
            background: #434db8;
        }
    </style>
</head>
<body>

    <form method="POST" action="">
        <h2>Retrieve Project Information</h2>
                <strong>Enter Project Name:</strong>
                <input type="text" name="project_name" required placeholder="Enter project name">
                <button type="submit" class="btn">Retrieve Project</button>
    </form>

    <div>
        <?php echo $project_details; ?>
    </div>
    <a href='work.php'>Go to Work</a>

</body>
</html>
