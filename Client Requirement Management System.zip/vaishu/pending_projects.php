<?php
// Check if the user is logged in
if (!isset($_COOKIE["uname"])) {
    header("Location: login.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shiva";

// Establish database connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve projects that are NOT completed
$sql = "SELECT project_name, deadline, status FROM project_info WHERE status != 'Completed'";
$result = mysqli_query($conn, $sql);

$pending_projects = "";

if (mysqli_num_rows($result) > 0) {
    $pending_projects .= "<table>
                            <tr>
                                <th>Project Name</th>
                                <th>Deadline</th>
                                <th>Status</th>
                            </tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        $pending_projects .= "<tr>
                                <td>{$row['project_name']}</td>
                                <td>{$row['deadline']}</td>
                                <td>{$row['status']}</td>
                              </tr>";
    }
    $pending_projects .= "</table>";
} else {
    $pending_projects = "<p style='color: red;'>No active projects found.</p>";
}

// Close connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Projects - V-Coder Technologies</title>
    <style>
        body {
            background: url('https://img.freepik.com/free-photo/abstract-networking-concept-still-life-assortment_23-2149035715.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Lucida Calligraphy', cursive;
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 70%;
            border-collapse: collapse;
            background: rgba(0, 0, 0, 0.6);
            border-radius: 8px;
            overflow: hidden;
            color: white;
        }
        th, td {
            padding: 12px;
            border: 1px solid white;
            text-align: center;
        }
        th {
            background: rgba(255, 255, 255, 0.3);
        }
        a
        {
            color:white;
        }
    </style>
</head>
<body>

    <h2>Active Projects</h2>
    <?php echo $pending_projects; ?>
<a href='work.php'>Go to work</a>
</body>
</html>
