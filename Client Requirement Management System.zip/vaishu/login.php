<?php

$uname = $_POST['username'];
$pwd = $_POST['password'];

$servername="localhost";
$username="root";
$password="";
$dbname="shiva";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
die("Connection failed:".mysqli_connect_error());
}
#echo("<h1>Connected Sucessfully</h1>");
$sql="select * from login where uname='$uname'";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);
if($row==NULL)
{
	echo "<center><h1>Invalid USername or Password</h1><br><a href='login.html'>Click me</a>";
}

if($row["password"]==$pwd)
{
    setcookie("uname", $uname, time() + 3600, "/", "", 0);
    echo "<h1>Welcome ".$uname."</h1><br><a href='work.php'>Start Work</a></center>";
}
else
{
    echo "<h1>Invalid Username or Password</h1><br><a href='login.html'>Try again</a></center>";
}
mysqli_close($conn);
?>
