<?php
if (!isset($_COOKIE["uname"])) {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "shiva";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $project_name = $_POST['project_name'];
    $client_name = $_POST['client_name'];
    $deadline = $_POST['deadline'];
    $type = $_POST['type'];
    $status = $_POST['status'];
    $assigned_to = $_POST['assigned_to'];
    $budget = $_POST['budget'];
    $description = $_POST['description'];

    $sql = "INSERT INTO project_info (project_name, client_name, deadline, type, status, assigned_to, budget, description) 
            VALUES ('$project_name', '$client_name', '$deadline', '$type', '$status', '$assigned_to', '$budget', '$description')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Project stored successfully!'); window.location.href='work.php';</script>";
    } else {
        echo "<script>alert('Error storing project: " . mysqli_error($conn) . "'); window.location.href='store_project.php';</script>";
    }

    mysqli_close($conn);
}
?>
