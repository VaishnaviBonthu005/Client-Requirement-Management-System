<?php
if (!isset($_COOKIE["uname"])) {
    header("Location: login.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shiva";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $project_name = $_POST['project_name'];
    $new_deadline = $_POST['deadline'];
    $new_type = $_POST['type'];
    $new_description = $_POST['description'];
    $new_status = $_POST['status'];

    $check_sql = "SELECT * FROM project_info WHERE project_name = '$project_name'";
    $check_res = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_res) > 0) {
        $update_sql = "UPDATE project_info 
                       SET deadline='$new_deadline', type='$new_type', description='$new_description', status='$new_status' 
                       WHERE project_name='$project_name'";
        if (mysqli_query($conn, $update_sql)) {
            echo "<script>alert('Project updated successfully!'); window.location.href='work.php';</script>";
        } else {
            echo "<script>alert('Error updating project: " . mysqli_error($conn) . "');</script>";
        }
    } else {
        echo "<script>alert('Project not found!');</script>";
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Project - V-Coder Technologies</title>
    <style>
        body {
            background: url('https://img.freepik.com/free-photo/abstract-networking-concept-still-life-assortment_23-2149035715.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Lucida Calligraphy', cursive;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        table {
            width: 100%;
        }
        td {
            padding: 10px;
        }
        input, select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn {
            background: #5c67f2;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background: #434db8;
        }
    </style>
</head>
<body>

    <form method="POST" action="">
        <h2>Update Project Information</h2>
        <table>
            <tr>
                <td>Project Name:</td>
                <td><input type="text" name="project_name" required placeholder="Enter project name"></td>
            </tr>
            <tr>
                <td>New Deadline:</td>
                <td><input type="date" name="deadline" required></td>
            </tr>
            <tr>
                <td>New Type:</td>
                <td><input type="text" name="type" required placeholder="Enter project type"></td>
            </tr>
            <tr>
                <td>New Description:</td>
                <td><input type="text" name="description" required placeholder="Enter project description"></td>
            </tr>
            <tr>
                <td>Project Status:</td>
                <td>
                    <select name="status" required>
                        <option value="Pending">Pending</option>
                        <option value="Ongoing">Ongoing</option>
                        <option value="Completed">Completed</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="2"><button type="submit" class="btn">Update Project</button></td>
            </tr>
        </table>
    </form>

</body>
</html>
