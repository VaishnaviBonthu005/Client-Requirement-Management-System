<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shiva";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$uname = $_POST['username'];
$pwd = $_POST['password'];
$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];

$check_sql = "SELECT * FROM login WHERE uname = '$uname'";
$result = mysqli_query($conn, $check_sql);

if (mysqli_num_rows($result) > 0) {
    echo "<h3 style='color:red;'>Username already exists. Try another one.</h3><br>";
    echo "<a href='register.html'>Go back to Registration</a>";
} else {

    $sql = "INSERT INTO login (uname, password, name, mobile, email) VALUES ('$uname', '$pwd', '$name', '$mobile', '$email')";

    if (mysqli_query($conn, $sql)) {
        echo "<h3 style='color:green;'>Registration Successful!</h3>";
        echo "<a href='login.html'>Go to Login</a>";
    } else {
        echo "<h3 style='color:red;'>Error in registration. Try again.</h3>";
        echo "<a href='register.html'>Go back to Registration</a>";
    }
}

mysqli_close($conn);
?>
