<?php
if (!isset($_COOKIE["uname"])) {
    header("Location: login.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shiva"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$clients = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $project_name = $_POST["project_name"];

    $sql = "SELECT * FROM client_info WHERE project_name = '$project_name'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $clients[] = $row;
        }
    } else {
        echo "<script>alert('No client found for this project!');</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retrieve Client Information</title>
    <style>
        a{
            color:white;
        }
        body {
            background: url('https://img.freepik.com/free-photo/abstract-networking-concept-still-life-assortment_23-2149035715.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: "Lucida Calligraphy", cursive;
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        form {
            background: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        input {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-family: "Lucida Calligraphy", cursive;
            width: 250px;
        }
        .btn {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background: #218838;
        }
        table {
            margin-top: 20px;
            width: 80%;
            border-collapse: collapse;
            background: rgba(0, 0, 0, 0.7);
            padding: 10px;
            border-radius: 10px;
        }
        th, td {
            border: 1px solid white;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #28a745;
        }
    </style>
</head>
<body>

<h2>Retrieve Client Information</h2>

<form method="post">
    <label>Enter Project Name:</label>
    <input type="text" name="project_name" placeholder="Enter Project Name" required>
    <button type="submit" class="btn">Retrieve</button>
</form>

<?php if (!empty($clients)) { ?>
    <table>
        <tr>
            <th>Client Name</th>
            <th>Client Email</th>
            <th>Client Mobile</th>
            <th>Project Name</th>
            <th>Address</th>
        </tr>
        <?php foreach ($clients as $client) { ?>
            <tr>
                <td><?php echo $client["client_name"]; ?></td>
                <td><?php echo $client["client_email"]; ?></td>
                <td><?php echo $client["client_mobile"]; ?></td>
                <td><?php echo $client["project_name"]; ?></td>
                <td><?php echo $client["address"]; ?></td>
            </tr>
        <?php } ?>
    </table><a href='work.php'>Go to Work</a>
<?php } ?>

</body>
</html>
