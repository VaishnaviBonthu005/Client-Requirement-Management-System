<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Work - V-Coder Technologies</title>
    <style>
        body {
            background: url('https://img.freepik.com/free-photo/abstract-networking-concept-still-life-assortment_23-2149035715.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: "Lucida Calligraphy", cursive;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
            text-align: center;
        }
        .logout {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        table {
            border-collapse: collapse;
            width: 60%;
            background: rgba(0, 0, 0, 0.6);
            padding: 20px;
            border-radius: 10px;
        }
        th, td {
            padding: 15px;
            border: 1px solid white;
        }
        button {
            padding: 10px;
            border: none;
            background: #ff6600;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-family: "Lucida Calligraphy", cursive;
        }
        button:hover {
            background: #cc5500;
        }
    </style>
</head>
<body>

<?php
if (!isset($_COOKIE["uname"])) {
    header("Location: login.html");
    exit();
}
?>

<a href="logout.php" class="logout">
    <button>Logout</button>
</a>

<h1>Employee Work Portal</h1>

<table>
    <tr>
        <th>Description</th>
        <th>Action</th>
    </tr>
    <tr>
        <td>Store Client Information</td>
        <td><a href="store_client.php"><button>Go</button></a></td>
    </tr>
    <tr>
        <td>Store Project Information</td>
        <td><a href="store_project.html"><button>Go</button></a></td>
    </tr>
    <tr>
        <td>Update Project Information</td>
        <td><a href="update_project.php"><button>Go</button></a></td>
    </tr>
    <tr>
        <td>Retrieve Project Information</td>
        <td><a href="retrieve_project.php"><button>Go</button></a></td>
    </tr>
    <tr>
        <td>Retrieve Pending Projects</td>
        <td><a href="pending_projects.php"><button>Go</button></a></td>
    </tr>
    <tr>
        <td>Retrieve Client Information</td>
        <td><a href="retrieve_client.php"><button>Go</button></a></td>
    </tr>
</table>

</body>
</html>
