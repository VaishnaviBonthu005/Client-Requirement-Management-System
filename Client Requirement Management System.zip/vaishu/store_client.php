<?php
if (!isset($_COOKIE["uname"])) {
    header("Location: login.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shiva"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $client_name = $_POST["client_name"];
    $client_email = $_POST["client_email"];
    $client_mobile = $_POST["client_mobile"];
    $project_name = $_POST["project_name"];
    $address = $_POST["address"];
    $sql = "INSERT INTO client_info (client_name, client_email, client_mobile, project_name, address) 
            VALUES ('$client_name', '$client_email', '$client_mobile', '$project_name', '$address')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Client information stored successfully!'); window.location.href='work.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href='store_client.php';</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store Client Information</title>
    <style>
        body {
            background: url('https://img.freepik.com/free-photo/abstract-networking-concept-still-life-assortment_23-2149035715.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: "Lucida Calligraphy", cursive;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        form {
            background: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 10px;
        }
        table {
            width: 100%;
        }
        td {
            padding: 8px;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-family: "Lucida Calligraphy", cursive;
        }
        .btn {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background: #218838;
        }
    </style>
</head>
<body>

<form method="post">
    <h2 align="center">Store Client Information</h2>
    <table>
        <tr>
            <td>Client Name:</td>
            <td><input type="text" name="client_name" placeholder="Enter Client Name" required></td>
        </tr>
        <tr>
            <td>Client Email:</td>
            <td><input type="email" name="client_email" placeholder="Enter Client Email" required></td>
        </tr>
        <tr>
            <td>Client Mobile:</td>
            <td><input type="text" name="client_mobile" placeholder="Enter 10-digit Mobile Number" required pattern="\d{10}" title="Enter a valid 10-digit mobile number"></td>
        </tr>
        <tr>
            <td>Project Name:</td>
            <td><input type="text" name="project_name" placeholder="Enter Project Name" required></td>
        </tr>
        <tr>
            <td>Address:</td>
            <td><textarea name="address" placeholder="Enter Address" rows="3"></textarea></td>
        </tr>
        <tr>
            <td colspan="2">
                <button type="submit" class="btn">Store Client</button>
            </td>
        </tr>
    </table>
</form>

</body>
</html>
